

# Print hello World and Hello manikandan

print("hello world!!!")

print("Hello Manikandan!")