import sys
sys.path.append("C:/Users/05444/PycharmProjects/Selenium/Python_Program_For_Selenium/Module_And_Packages/importing_classes_from_different_modules_And_packages/pack1/emp.py")

import emp

empObj=emp.Employess(1,"mani",10000)

empObj.displayemp()