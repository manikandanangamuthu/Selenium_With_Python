

def add(x,y):

    print("Adding two numbers: ",x+y)

def mul(x,y):

    print("Multiply of two number: ",x*y)

def sub(x,y):

    print("Subtraction of two number: ",x-y)

def div(x,y):
    print("divided of two numbers: ",x%y)


# Call the functions from same module
#
# add(10,20)
# mul(10,20)
# div(10,20)
# sub(10,20)