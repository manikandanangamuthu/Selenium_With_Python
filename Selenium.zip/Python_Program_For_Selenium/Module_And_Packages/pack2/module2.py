
def show():
    print("This is show function ")