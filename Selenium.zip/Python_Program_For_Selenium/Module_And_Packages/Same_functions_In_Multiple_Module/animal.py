

def walk():
    print("Animal can Walk...")

def talk():
    print("Animal can not Speak..")

def fly():
    print("Animal can not fly")