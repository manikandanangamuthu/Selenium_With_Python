
def walk():
    print("Human can Walk...")

def talk():
    print("Human can Speak..")

def fly():
    print("Human can not fly")