
def walk():
    print("Bird can Walk...")

def talk():
    print("Bird can not Speak..")

def fly():
    print("Bird can fly")