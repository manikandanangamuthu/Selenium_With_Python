import sys
#
sys.path.append("C:/Users/05444/PycharmProjects/Selenium/Python_Program_For_Selenium/Module_And_Packages/package")
#
# Approach 1
#
# import module1
# import module2
#
# module1.display()
# module2.show()

#==============================================

from module1 import *
from module2 import *

display()
show()