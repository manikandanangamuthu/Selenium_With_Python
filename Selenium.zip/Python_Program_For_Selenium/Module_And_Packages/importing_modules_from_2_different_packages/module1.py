

def display():

    print("This is display function..")