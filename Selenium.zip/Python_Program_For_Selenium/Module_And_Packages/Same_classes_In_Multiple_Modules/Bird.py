class bird():
    def fly(self):
        print("Bird can fly")
    def talk(self):
        print("Bird can not talk")
    def walk(self):
        print("Bird can walk..")