class animal():
    def fly(self):
        print("Animal can not fly")
    def talk(self):
        print("Animal can not talk")
    def walk(self):
        print("Animal can walk..")