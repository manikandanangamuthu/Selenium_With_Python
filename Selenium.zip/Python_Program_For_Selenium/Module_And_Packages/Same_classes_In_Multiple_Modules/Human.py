class human():
    def fly(self):
        print("Human can not fly")
    def talk(self):
        print("Human can talk")
    def walk(self):
        print("Human can walk..")