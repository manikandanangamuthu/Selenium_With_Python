# # # # # #
# # # # # #
# # # # # # # Module & Packages
# # # # # # -----------------------
# # # # # #
# # # # # # Module --->> Collection of funtions, Classes(Variables+methods)
# # # # #
# # # # # Exampls
# # # # #
# # # # # 1) How to create a module
# # # # #
# # # # # 2) How to call the functions from same module
# # # # #
# # # # # 3) How to call the functions from one module to another module..
# # # # #
# # # #
# # # # # Approach 1 : import moduleName
# # # # # Approach 2 : From modulename import functions, classes
# # # #
# # # #
# # # # Packages
# # # # =========
# # # #
# # # # Collections of modules...
# # # # Package -->>>Modules ---->> functions & Classes
# # #Ex 1
# # # pack 1 ==>> Module 1 ==> function ex: display()
# # #        ===>> Module 2 ==>> function  ex: show()
# #=============================================================
# # Ex 2
# # Package ====> Module1==> display()
# # Package==>> package1 ===>> module2==>>show()
# #============================================================
#
# #Ex 3
# Package   # Module   # Classes   # Method
# pack1      emp         Employee     displayemp()
# pack2      stu         Student      displaystu()
# pack3      client