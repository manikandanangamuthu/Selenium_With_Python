

def display():
    print("This is display function from module 1")