

def show():
    print("This is show function from module 1")