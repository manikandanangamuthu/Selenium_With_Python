

# #method 1
#
# a,b,c=2,10,4
#
# if a>b:
#     print(a)
# elif b>c:
#     print(b)
# else:
#     print(c)

#===============================================================

num1=int(input("Enter 1st number: "))

num2=int(input("Enter 2nd number: "))

num3=int(input("Enter 3rd number: "))

if num1>num2:
    print(num1)
elif num2>num3:
    print(num2)
else:
    print(num3)