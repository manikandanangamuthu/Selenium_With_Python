# method 1
#
# num1=int(input("Enter 1st number: "))
# num2=int(input("Enter 2nd number: "))
#
# if num1>num2:
#     print(num1)
# else:
#     print(num2)


# Method 2

a,b=10,5

print(a if a>b else b)