

num=int(input("Enter your number: "))

if num>0:
    print("Given number is positive number")
else:
    print("Negative Number ")