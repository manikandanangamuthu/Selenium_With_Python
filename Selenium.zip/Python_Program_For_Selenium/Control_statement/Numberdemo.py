

num1=100
num2=10.4

print(type(num1))

print(type(num2))

# find the maximum & minimum number in the list

print(max(10,3,100,34,20,342,8765,0,8,6,34))

print(min(10,3,100,34,20,342,8765,1,8,6,34))

# find the maximum & minimum number in the list

print(max(10.56,3.78,100.87,34.90,20.96,))

print(min(10.56,3.78,100.87,34.90,20.96,))

