
# range --> Value between the range



print(range(20))

print(list(range(20)))         # [0 to 20-1(19)] N-1
print(list(range(100,110))) # 100-starting point 110-ending point
print(list(range(10,50,5))) # 10-starting point 50-ending point 5- increment value

print(list(range(0,10,2))) # even number

print(list(range(0,10,1))) # add number


print(list(range(10,1,-1))) # decrese the value


print(list(range(-10,-5))) # negative numbers


print(list(range(-10,-5,2)))