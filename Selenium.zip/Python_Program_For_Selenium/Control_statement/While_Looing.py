#
#
# # While Loop
#
# # print 1 to 10
#
# i=1 #initilization
#
# while i<=10:
#     print(i)
#     i=i+1
# print("Done!!!")

#==========================================================

# print 1 to 10 decenting order


i=10
while i>=1:                   # 10>=1
    print(i)
    i=i-1
print("Done !!!!!")





