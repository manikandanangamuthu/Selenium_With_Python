#
#
# # break     #continue
#
# for i in range(1,10):
#     if i==5:
#         break
#     print(i)
# print("Loop exited")


#=======================================

for i in range(1,10):
    if i==5:
        continue
    print(i)
print("Continue Loop!!!!!!!!")