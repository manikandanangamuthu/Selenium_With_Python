

# print 1 to 10 using for loop conditions


# for i in range(10):
#     print(i)

#==============================================

# print 1 to 10 exactly
#
# for i in range(1,10):
#     print(i)

#===================================

# print 1 to 10 add number

# for i in range(1,10,2):
#     print(i)

#====================================
# # print 1 to 10 even number
#
# for i in range(0,11,2):
#     print(i)
#

# print 10 to 1 descending order

for i in range(10,0,-1):
    print(i)