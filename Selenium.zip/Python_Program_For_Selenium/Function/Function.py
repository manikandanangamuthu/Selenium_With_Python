

# Example 1

# def myfun():
#     print("Hello World")
# myfun()  # call the funcion

#=============================================
#
# #Example 2
# def myfun(name):
#     print("Hi",name)
# myfun("Mani")
#
#============================================

# # Example 3
#
# def myfun(a,b):
#     return(a+b)
#
# #sum=myfun(10.50,20)
# print(sum)
# # or
# print(myfun(10.50,20))

# ==============================================
#
# # Example 4
#
# def myfun():
#     return
# print(myfun())
#===============================================

# Example 5

# def myfun(a,b):
#     return (a+b)
# print(myfun(20,30))

#==============================================

def myfun(a,b):
    print(a+b)
myfun(30,30)