

# Example 1

# def func(i, j):
#     print(i, j)
# func(10,20) # Postional Arguments
#
# func(i=10,j=20) # Keyword arguments

#=======================================

# Example 2-->>  default value assigned to positional arguments

def func(i,j=20):
    print(i,j)
func(100,200)
func(150)