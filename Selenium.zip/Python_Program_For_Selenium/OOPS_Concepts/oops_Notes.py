# # # #
# # # #
# # # # # Python - structured + object oriented
# # # #
# # # #
# # # # oops(object oriented programming concepts)
# # # # -----------
# # # #
# # # # class
# # # # object
# # # # inheritance
# # # # polymorphism
# # # #
# # # # class object
# # # #
# # # # # Employee --  jone, mani, chandru  etc......
# # # #
# # # # # Animal ------->> Dog, Horse,Elephant, etc...
# # #
# # # class --->> collection of variables (attributes) & methods (behavior)
# # #
# # # A class is blue print
# # # Logical entity
# # # Does not occupy space in the memoryview
# # #
# # # object  --->> object is an instance of class
# # # physical entity
# # #
# # # occupy certain amount space in the memory
# #
# # For one class, we can create multiple objects..
# # objets are independent...
# #
# # Function Vs Method --> we can create without class
# # Method ---> creates in side the class
#
# 2 types of method we can define within the calss
#
# 1) instance method (we can call only through object)
# 2) static method (we can directly call using class)

#annotation @staticmethod

Global variable
class variable
local variable

Method & constructor

Method :    give any name
            return the value/s
            method can take argumetns /parameters
            we have to use an object to invoke the method
Constructor : contructor name is fixed:
             def  __init__(self):
    Constructor will not return any value
    Constructor can also take arguments /parameters
    condstructor will be called at the time of object craetetion itself