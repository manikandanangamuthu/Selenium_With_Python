

# Single line comment  CRL+/

# print("Single line Comment")

# Multiple line comments CRL+Shift+/



# print("hello world")
# print("Manikandan")