
# Approach 1
# name = "Mani"
# age =27
# Sal=26000
#
# print (name)
# print(age)
# print(Sal)

# Appproach 2

name,age,sal=("Mani",27,26000)
#print(name,age,sal)

# Approach 3

# print("Name is:",name)
#
# print("Age is:",age)
#
# print("Sal is:",sal)

# Approach 4 %

print("Name is:%s and Age is:%d and Sal is:%g" %(name,age,sal))

# Approach 4 {}

print("Name is:{} and Age is:{} and Sal is:{}" .format(name,age,sal))

