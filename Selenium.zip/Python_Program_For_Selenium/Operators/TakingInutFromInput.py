# num1=input("Enter first number: ")
# num2=input("Enter Second number: ")
#
# print(type(num1))
# print(type(num2))
# print(num1+num2)  # 100200

# Approach 1
#
# num1=int(input("Enter first number: "))
# num2=int(input("Enter Second number: "))
# print(type(num1))
# print(type(num2))
# print(num1+num2)

num1=(input("Enter first number: "))
num2=(input("Enter Second number: "))
print(type(num1))
print(type(num2))
print(int(num1)+int(num2))





