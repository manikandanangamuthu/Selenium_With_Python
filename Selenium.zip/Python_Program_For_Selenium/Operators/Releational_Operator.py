
# Relational Operator / Comparison Operator


# > --> graterthan
# < --> Lessthan
# >=  --> Graterthan or equal
# <=  -->> Lessthan or equal
# !=   -->> Not equal
# == --> Equal
# Relational value always return boolean value True/False
a= 5
b=10

print(a>b)  # False
print(a<b) # true
print(a>=b) # false
print(a<=b) # false
print(a!=b) # false
print(a==b) # false
