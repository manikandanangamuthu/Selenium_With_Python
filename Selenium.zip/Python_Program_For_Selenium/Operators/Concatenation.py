

print (10+10) # valid

print (10.5+10) # valid

print (10+10.20) # Valid

print (20.5+20.5) # Valid

print ('mani'+'kandan') # valid

print (True+10) # valid

print(20+False) # valid

print (10+'mani') # not valid

print(20.50+'mani') # not valid


print(20.50+'Ture') # not valid
