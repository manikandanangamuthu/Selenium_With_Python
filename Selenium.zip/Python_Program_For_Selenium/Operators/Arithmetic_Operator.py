

# Arithmetic Operators

a= 5
b= 2


print(a+b) #  Addition 5+2 = 7
print(a-b) #  Subtraction 5-2=3
print(a*b) # Multiplication 5*2=10
print(a/b) # 2.5
print(a//b) # 2 quotient
print(a%b)   # 1 reminder
print(a**b)  # 5**2 = 25