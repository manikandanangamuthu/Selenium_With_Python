# # #
# # # Exception is an event which will cause program termination
# # #
# # # try,except, else, finally
# #
# # except--> executes only when exception occured
# # else---> exceutes only exceptions not occured
# # finally --->> always excutes....
# #
# # File Handling/ working with the text
#
#
# 2 thins important
#
# 1. File path
#
# 2. Mode -> Writing-w and reading-r and appeand-

# Whenever file should open once work complete file should be close