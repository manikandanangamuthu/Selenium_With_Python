

# 2) Get a integer number from user and pass to function called findevenodd().
# Let the function print whether add or even
def findevenodd(num):

    if num%2==0:
        print("This is even number")
    else:
        print("This is odd number ")


num= int(input("Enter the Number: "))
findevenodd(num)



