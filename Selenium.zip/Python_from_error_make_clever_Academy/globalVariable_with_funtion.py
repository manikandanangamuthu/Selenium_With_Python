a = int(input("Enter a Value: "))
b = int(input("Enter b value: "))

def add():
    print(a+b)

def mul():

    print(a*b)

def sub():

    print(a-b)
def div():

    print(a%b)

add()
mul()
sub()
div()