

def add():
    a = int(input("Enter a Value: "))
    b = int(input("Enter b value: "))
    print(a+b)

def mul():
    a=int(input("Enter a Value: "))
    b=int(input("Enter b value: "))
    print(a*b)

def sub():
    a=int(input("Enter a value: "))
    b=int(input("Enter b value: "))
    print(a-b)
def div():
    a = int(input("Enter a value: "))
    b = int(input("Enter b value: "))
    print(a%b)

add()
mul()
sub()
div()
    

