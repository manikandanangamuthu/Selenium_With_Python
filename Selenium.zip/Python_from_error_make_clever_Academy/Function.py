

def painter():

    print("painting")

painter()